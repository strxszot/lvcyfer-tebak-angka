# Terminal version

Run the Python script:

```
python3 tebak_angka.py
```
