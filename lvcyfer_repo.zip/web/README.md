# Web version

This folder contains the `index.html` for the web version of Tebak Angka.
